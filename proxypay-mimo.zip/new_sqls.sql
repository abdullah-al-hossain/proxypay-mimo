INSERT INTO `business_settings` (`id`, `type`, `value`, `created_at`, `updated_at`) VALUES (NULL, 'proxypay', '1', current_timestamp(), current_timestamp());
