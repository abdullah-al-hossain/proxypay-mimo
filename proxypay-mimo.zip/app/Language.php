<?php

namespace App;

use Illuminate\Database\Eloquent\Model;
use App;

class Language extends Model
{
  //
}
